module ProyectoIPJ {
	requires java.desktop;
}